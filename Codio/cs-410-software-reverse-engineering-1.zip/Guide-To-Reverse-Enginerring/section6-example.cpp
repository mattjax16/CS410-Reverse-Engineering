#include <iostream>
using namespace std;
int main()
{
  int i;
  i = 171;
  return 0;
}